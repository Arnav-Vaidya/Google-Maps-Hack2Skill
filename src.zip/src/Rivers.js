import React from "react";
import { useLoadScript } from "@react-google-maps/api";
// import { GoogleMap, useLoadScript, Marker } from "@react-google-maps/api";
import GoogleMapReact from 'google-map-react';

const Ganga = ({ text }) => <div className="marker">{text}</div>;
const Godavari = ({ text }) => <div className="marker">{text}</div>;
const Narmada = ({ text }) => <div className="marker">{text}</div>;
const Kaveri = ({ text }) => <div className="marker">{text}</div>;
const Krishna = ({ text }) => <div className="marker">{text}</div>;

function Rivers() {
  const { isLoaded } = useLoadScript({
    googleMapsApiKey: 'AIzaSyCJHsYMqOqXP5NgLYMlL-S-dZ1o98JBlfQ',
  });

  if (!isLoaded) return <div>Loading...</div>;
    return <RiverMap />;
}

function RiverMap() {
  const defaultCenter = {
    lat: 22.461933616907906,
    lng: 77.75111400018005
  };
  const zoom = 5;

  return (
    <div style={{ width: '100%', height: '100vh'}}>
      <GoogleMapReact
        bootstrapURLKeys={{ key: 'AIzaSyCJHsYMqOqXP5NgLYMlL-S-dZ1o98JBlfQ' }} 
        defaultCenter={defaultCenter}
        defaultZoom={zoom}
      >
        <Ganga lat = { 30.994321514722085 } lng = { 78.94072641269705 } text="Ganga" />
        <Godavari lat = { 19.165223630003275 } lng = { 78.4379594509368 } text="Godavari" />
        <Narmada lat = { 22.682893307238 } lng = { 81.75252890596606 } text="Narmada" />
        <Kaveri lat = { 12.383808536703159 } lng = { 75.49409857878564 } text="Kaveri" />
        <Krishna lat = { 17.93096577998276 } lng = { 73.64757977497398 } text="Krishna" />
      </GoogleMapReact>
  </div>
  );

// Marker code with different option but is not working
/*   return (
    <div style={{ width: '100%', height: '100vh' }}>
      <GoogleMap
		    zoom = {5}
        center={defaultCenter}
      >
        <Marker position={{ lat=30.994321514722085 lng=78.94072641269705 />
      </GoogleMapReact>
    </div>
  ); */
}

export default Rivers;

