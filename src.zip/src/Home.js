import React from "react";

function Home () {
    return (
        <div className="background">
            <h1>Welcome to <a href="/rivers">Rivers of India</a></h1>
        </div>
    )
};

export default Home;